﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication10.Models
{
    public class Course
    {
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        public Leader Leader { get; set; }
        public int DirectionId { get; set; }
        public List<CoursePerson> CoursePerson { get; set; }

        public Course()
        {
            CoursePerson = new List<CoursePerson>();
        }
    }
}
