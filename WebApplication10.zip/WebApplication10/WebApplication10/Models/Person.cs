﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication10.Models
{
    [Table("Student")]
    public class Person
    {
        [Key]
        public int Id { get; set; }
        [Column("FirstName")]
        public string Name { get; set; }
        public string Surname { get; set; }
        [NotMapped]
        public int Age { get; set; }
        public List<CoursePerson> CoursePerson { get; set; }

        public Person()
        {
            CoursePerson = new List<CoursePerson>();
        }
    }
}
