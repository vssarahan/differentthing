﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication10.Models
{
    public class EF2Context: DbContext
    {
        public EF2Context(DbContextOptions<EF2Context> opt): base(opt)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<CoursePerson>()
                .HasKey(cp => new { cp.CourseId, cp.PersonId });
        }

        public DbSet<Direction> Directions { get; set; }
        public DbSet<Course> Courses { get; set; }
        public DbSet<Person> Persons { get; set; }
        public DbSet<Leader> Leaders { get; set; }
        public DbSet<CoursePerson> CoursePerson { get; set; }
    }
}
