﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication10.Models
{
    public class CoursePerson
    {
        public int CourseId { get; set; }
        public int PersonId { get; set; }
    }
}
